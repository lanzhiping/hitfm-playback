module.exports = {
  toBackground: {
    load: "load",
    play: "play",
    seek: "seek",
    pause: "pause",
    opened: "opened",
    selected: "selected",
    selectedDate: "selectedDate",
    selectedProgram: "selectedProgram",
  },
  buildMessage: (command, value) => ({
    command,
    value,
  }),
};
